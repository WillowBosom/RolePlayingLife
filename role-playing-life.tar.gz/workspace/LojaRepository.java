package br.com.herbertrausch.domain;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface LojaRepository extends CrudRepository<Loja, Long>{
	
	List<Loja> findByIdLoja(Long IdLoja);
	List<Loja> findByIdItem(Long IdItem);
	List<Loja> findByNomeItem(String NomeItem);
	List<Loja> findByTipoItem(Long TipoItem);
	List<Loja> findByPreco(Long Preco);
	
}

