package br.com.herbertrausch.domain;

import java.util.List;

public interface LojaRepositoryCustom {
	
	
	Loja findByIdLoja(Long IdLoja);
	Loja findByIdItem(Long IdItem);
	Loja findByNomeItem(String NomeItem);
	Loja findByTipoItem(Long TipoItem);
	Loja findByPreco(Long Preco);
}
