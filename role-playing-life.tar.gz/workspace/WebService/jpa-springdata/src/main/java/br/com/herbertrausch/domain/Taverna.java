package br.com.herbertrausch.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Taverna implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long IdTaverna;
	private Long IdUsuario;
	private Long mensagem;
	
	
	public Long getIdTaverna() {
		return IdTaverna;
	}
	public void setIdTaverna(Long idTaverna) {
		this.IdTaverna = IdTaverna;
	}
	public Long getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}
	public Long getmensagem() {
		return idmensagem;
	}
	public void setmensagem(Long mensagem) {
		this.mensagem = mensagem;
	}
	
	@Override
	public String toString() {
		return "batata";
	}
}
