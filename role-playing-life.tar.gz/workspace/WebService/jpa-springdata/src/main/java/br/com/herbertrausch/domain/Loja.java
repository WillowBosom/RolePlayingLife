package br.com.herbertrausch.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Loja implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idLoja;
    private Long idItem;
   	private String NomeItem;
	private Long TipoItem;
	private Long Preco;

	public Long idLoja() {
		return idLoja;
	}
	public void setIdLoja(Long idLoja) {
		this.idLoja = idLoja;
	}
	public Long getIdLoja() {
		return idLoja;
	}
	public void setIdItem(Long IdItem) {
		this.IdItem = IdItem;
	}
	public Long getIdItem() {
		return idItem;
	}
	
	public void setNomeItem(String NomeItem) {
		this.NomeItem = NomeItem;
	}
	
	public String getNomeItem() {
		return NomeItem;
	}
	
	public Long getTipoItem() {
		return TipoItem;
	}

	public void setTipoItem(Long TipoItem) {
		this.TipoItem = TipoItem;
		
	public Long getPreco() {
		return Preco;
	}
	
	public void setPreco(Long Preco) {
		this.Preco = Preco;
	
	@Override
	public String toString() {
		return "batata";
	}
}
