package br.com.herbertrausch.domain;

import java.util.List;

public interface TavernaRepositoryCustom {
	
	Taverna findByIdTaverna(Long IdTaverna);
	Taverna findByIdUsuario(Long IdUsuario);
	Taverna findBymensagem(Long mensagem);
}
