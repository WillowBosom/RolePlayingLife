package br.com.herbertrausch.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Party implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idParty;
	private Long idUsuario1;
	private Long idUsuario2;
	private Long idUsuario3;
	private Long idUsuario4;
	private Long idUsuario5;
	private Long idUsuario6;	
	
	public Long getIdParty() {
		return idParty;
	}
	public void setIdParty(Long idParty) {
		this.idParty = idParty;
	}
	public Long getIdUsuario1() {
		return idUsuario1;
	}
	public void setIdUsuario1(Long idUsuario1) {
		this.idUsuario1 = idUsuario1;
	}
	public Long getIdUsuario2() {
		return idUsuario2;
	}
	public void setIdUsuario2(Long idUsuario2) {
		this.idUsuario2 = idUsuario2;
	}
	public Long getIdUsuario3() {
		return idUsuario3;
	}
	public void setIdUsuario3(Long idUsuario3) {
		this.idUsuario3 = idUsuario3;
	}
	public Long getIdUsuario4() {
		return idUsuario4;
	}
	public void setIdUsuario4(Long idUsuario4) {
		this.idUsuario4 = idUsuario4;
	}
	public Long getIdUsuario5() {
		return idUsuario5;
	}
	public void setIdUsuario5(Long idUsuario5) {
		this.idUsuario5 = idUsuario5;
	}
	public Long getIdUsuario6() {
		return idUsuario6;
	}
	public void setIdUsuario6(Long idUsuario6) {
		this.idUsuario6 = idUsuario6;
	}
	
	@Override
	public String toString() {
		return "batata";
	}
}
