package br.com.herbertrausch.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.herbertrausch.domain.Loja;
import br.com.herbertrausch.domain.LojaService;
import br.com.herbertrausch.domain.Response;

@Path("/Lojas")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class LojasResource {
	
	public LojaService LojaService = new LojaService();
	

	@GET
	public List<Loja> get() {
		List<Loja> Lojas = LojaService.getLojas();
		return Lojas;
	}

	@GET
	@Path("{NomeItem}")
	public Loja get(@PathParam("NomeItem") string a) {
		Loja c = LojaService.getLoja(a);
		return c;
	}

	@GET
	@Path("/NomeItem/{NomeItem}")
	public List<Loja> getByNomeItem(@PathParam("NomeItem") String NomeItem) {
		List<Loja> Lojas = LojaService.getByNomeItem(NomeItem);
		return Lojas;
	}
	

	@GET
	@Path("/TipoItem/{TipoItem}")
	public List<Loja> getByTipoItem(@PathParam("TipoItem") Long TipoItem) {
		List<Loja> Lojas = LojaService.getByTipoItem(TipoItem);
		return Lojas;
	}
	
	@DELETE
	@Path("{idLoja}")
	public Response delete(@PathParam("idLoja") long idLoja) {
		LojaService.delete(idLoja);
		return Response.Ok("Loja deletado com sucesso");
	}

	@POST
	public Response post(Loja c) {
		LojaService.save(c);
		return Response.Ok("Loja salvo com sucesso");
	}

	@PUT
	public Response put(Loja c) {
		LojaService.save(c);
		return Response.Ok("Loja atualizado com sucesso");
	}

}
