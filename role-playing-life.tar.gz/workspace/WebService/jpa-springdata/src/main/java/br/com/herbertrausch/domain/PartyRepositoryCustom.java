package br.com.herbertrausch.domain;

import java.util.List;

public interface PartyRepositoryCustom {
	
	Party findByIdParty(Long idParty);
	Party findByIdUsuario1(Long idUsuario1);
	Party findByIdUsuario2(Long idUsuario2);
	Party findByIdUsuario3(Long idUsuario3);
	Party findByIdUsuario4(Long idUsuario4);
	Party findByIdUsuario5(Long idUsuario5);
	Party findByIdUsuario6(Long idUsuario6);
}