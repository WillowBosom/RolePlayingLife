package br.com.herbertrausch.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import br.com.herbertrausch.util.SpringUtil;

public class LojaService {

	
	private LojaRepository db;
	
	public LojaService(){
		
		ApplicationContext context=SpringUtil.getContext();
		db = context.getBean(LojaRepository.class);
		
	}

	// Lista todos os clinetes do banco de dados
	public List<Loja> getLoja() {
		try {
			
			List<Loja> Loja = (List<Loja>) db.findAll();
					
			return Loja;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<Loja>();

		}
	}
	
	public List<Loja> findByIdLoja(Long a){
		return db.findByIdLoja(a);
	}
	
	public List<Loja> findByIdItem(Long a){
		return db.findByIdItem(a);
	}
	
	public List<Loja> findByNomeItem(String a){
		return db.findByNomeItem(a);
	}
	
	public List<Loja> findByTipoItem(Long a){
		return db.findByTipoItem(a);
	}
	
	public List<Loja> findByPreco(Long a){
		return db.findByPreco(a);
	}
	
	public Loja getLoja(Long id) {
		try {
			
			
			return db.findOne(id);
			
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}


	public boolean delete(Long id) {
		try {
			db.delete(id);
			return true;
		} 
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean save(Loja IdLoja) {
		try {
			
				db.save(IdLoja);
			
			return true;
		}  catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}



}
