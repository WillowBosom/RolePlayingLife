package br.com.herbertrausch.domain;

import java.util.List;

public interface GuildaRepositoryCustom {
	
	Guilda findByIdGuilda(Long idGuilda);
	Guilda findByIdUsuario(Long idGuilda);
	Guilda findByrankGuilda(Long rankGuilda);
}
