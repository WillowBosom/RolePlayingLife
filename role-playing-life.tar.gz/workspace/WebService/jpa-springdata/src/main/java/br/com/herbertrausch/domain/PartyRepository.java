package br.com.herbertrausch.domain;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface PartyRepository extends CrudRepository<Party, Long>{
	
	List<Party> findByIdParty(Long IdParty);
	List<Party> findByIdUsuario1(Long IdUsuario1);
	List<Party> findByIdUsuario2(Long IdUsuario2);
	List<Party> findByIdUsuario3(Long IdUsuario3);
	List<Party> findByIdUsuario4(Long IdUsuario4);
	List<Party> findByIdUsuario5(Long IdUsuario5);
	List<Party> findByIdUsuario6(Long IdUsuario6);
	
}

