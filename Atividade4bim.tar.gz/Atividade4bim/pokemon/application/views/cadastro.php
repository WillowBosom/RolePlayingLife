
<div class="input-group">

<fieldset>

<!-- Form Name -->
<legend>Cadastrar Pokemon</legend>
<form name="formCadastro" id="formCadastro" class="form-horizontal" enctype="multipart/form-data" method="POST" action="http://localhost/pokemon/index.php/Cadastro/cadastrar">
            <label class="input-group">Nome do Pokemon:</label>
                          <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-font"></i></span>
                              <input id="nome" type="text" class="form-control" name="nome" placeholder="Nome" required="">
                          </div>
                          <br>
                          <label class="input-group">Data da captura:</label>
                            <div class="input-group">

                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input id="data_captura" type="text" class="form-control" name="data_captura" placeholder="AAAA-MM-DD" required="">
                            </div>
                            <br>
                            <div class="dropdown">
                              <label class="input-group">Tipo:</label>

                              <select data-toggle="dropdown" id="tipo_pokemon" name="tipo_pokemon" class="btn btn-primary dropdown-toggle" required=""><span class="caret"></span>
                                    <ul class="dropdown-menu">
                                        <option value="" disabled selected hidden>Tipo</option>
                                        <option value="Verde">Verde</option>
                                        <option value="Laranja">Laranja</option>
                                        <option value="Vermelho">Vermelho</option>

                                    </ul>
                              </select>

                            </div>
                            <br>
                            <div class="form-group">
                                <!-- Button -->
                                <div class="col-sm-12 controls">

                                        <button type="submit" href="#" class="btn btn-success"><i class="fa fa-sign-in"></i> Cadastrar</button>
                                        <a id="botao" class="btn btn-danger" href="http://localhost/pokemon/index.php/Home" >Cancelar</a></li></th><br />


                                </div>
                            </div>

                        </form>
</fieldset>

</div>
