<div id="homebody">
		<h2>Pokemons</h2>
		<div class ="alinhado-centro borda-base espaco-vertical">
  	</div>
  	<div class="row-fluid">
			<table class="table">
    <thead>
      <tr>
				<th>Id</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Data de Captura</th>
				<th>Editar</th>
				<th>Excluir</th>
      </tr>
    </thead>
    <tbody>

      <tr class="default">
				<?php
              foreach($pokemon as $pok) {
                       echo "<tr>";
											 	echo "<td>".$pok->id_pokemon."</td>";
                         echo "<td>".$pok->nome."</td>";
                         echo "<td>".$pok->tipo_pokemon."</td>";
                         echo "<td>".$pok->data_captura."</td>";
                        echo "<td><a href='http://localhost/pokemon/index.php/Editar'><button type='submit' class='btn btn-success'>Editar</button></a></td>";
												echo"<td><a><button type='submit' class='btn btn-danger'>Excluir</button></a></td>";
                     }
                  ?>

      </tr>

    </tbody>
  </table>
</div>
  </div>
 </div>
