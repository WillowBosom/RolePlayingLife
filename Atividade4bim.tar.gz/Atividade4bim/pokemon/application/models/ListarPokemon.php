<?php

defined('BASEPATH') OR exit('No direct script access allowed');

  class ListarPokemon extends CI_Model {
    public function __construct(){
      parent::__construct();
    }
    public function list_pokemon(){
      return $this->db->get('pokemon')->result();
    }
  }

?>
