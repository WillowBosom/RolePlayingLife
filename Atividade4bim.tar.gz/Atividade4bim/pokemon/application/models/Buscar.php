<?php

defined('BASEPATH') OR exit('No direct script access allowed');

  class Buscar extends CI_Model {
    public function __construct(){
      parent::__construct();
    }
    public function busca ($buscar) {
      $this->db->like('tipo_pokemon', $buscar);
      $this->db->or_like('nome', $buscar);
      return $this->db->get('pokemon')->result();
      }
    }

?>
