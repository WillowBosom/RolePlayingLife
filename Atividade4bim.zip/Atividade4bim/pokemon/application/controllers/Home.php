<?php defined('BASEPATH') OR exit('No direct script access allowed');
 class Home extends CI_Controller {
		 private $pokemon;
     private $var;
 		 public function __construct(){
  	  			parent::__construct();
            $this->load->model("ListarPokemon","listarpokemonmodel");
            $this->pokemon = $this->listarpokemonmodel->list_pokemon();
 		 }
  	public function index(){
		    $this->load->helper('text');
        	$dados['pokemon']=$this->pokemon;
  		    $this->load->view('html-header');
 		    $this->load->view('header',$dados);
  		    $this->load->view('home',$dados);
  		    $this->load->view('footer');
		    $this->load->view('html-footer');
   }
   public function pesquisar(){
         $this->load->helper('text');
         $this->load->model("Buscar","buscarpokemonmodel");
         //$dados['pokemon']=$this->pokemon;
         $busca = $this->input->post('txt_busca');
         $dados_busca['termo'] = $busca;
         $dados_busca['pk'] = $this->buscarpokemonmodel->busca($busca);
         $this->load->view('html-header');
         $this->load->view('header',$dados_busca);
         $this->load->view('busca',$dados_busca);
         $this->load->view('footer');
         $this->load->view('html-footer');
  }
	
	
       
 }

