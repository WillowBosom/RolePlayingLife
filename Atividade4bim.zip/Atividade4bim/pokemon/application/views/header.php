<div class="container">
	<div class ="masthead">

			<h3>Pokemon <span class="label label-primary">GO</span></h3><br>
			<nav class="navbar navbar-default">

		  <ul class="nav navbar-nav">
			  <li class="active"><a href="http://localhost/pokemon/index.php/Home">Pokemons</a></li>
				<li><a href="http://localhost/pokemon/index.php/Cadastro">Cadastrar Pokemon</a></li>
				<form class="navbar-form navbar-left">
					 <div class="form-group">
						 <input type="text" name="txt_busca"class="form-control" placeholder="Search">
					 </div>
					 <a href="http://localhost/pokemon/index.php/Home/pesquisar"><button type="button" class="btn btn-default">Buscar</button></a>
		 	 </form>

			  <ul class="nav navbar-nav navbar-right">
					<?php echo "<li><a>". $this->session->userdata('usuario')->nome." "."</a></li>"
	?>
					<li><a href="http://localhost/pokemon/index.php/Login/sair">Sair</a></li>
			 </ul>

		 </ul>
	 </nav>

  </div>
