<div id="homebody">
		<h2>Pokemons</h2>
		<div class ="alinhado-centro borda-base espaco-vertical">


    </tr>

      <h3> Você buscou por: <?php echo $termo  ?> </h3>
      <p> Os seguintes resultados foram encontrados. </p>
  	</div>
  	<div class="row-fluid">
			<table class="table">
    <thead>
      <tr>
				<th>Id</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Data de Captura</th>

      </tr>
    </thead>
    <tbody>


      <tr class="default">
				<?php
              $cont=0;
              foreach($pk as $pks) {
                $cont++;
                       echo "<tr>";
											 	echo "<td>".$pks->id_pokemon."</td>";
                         echo "<td>".$pks->nome."</td>";
                         echo "<td>".$pks->tipo_pokemon."</td>";
                         echo "<td>".$pks->data_captura."</td>";

                     }
                  ?>

      </tr>

    </tbody>
  </table>
</div>
  </div>
 </div>
