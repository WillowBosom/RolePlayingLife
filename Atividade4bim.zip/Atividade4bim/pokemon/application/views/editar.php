
<div class="input-group">
  <form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Editar</legend>
<div class ="alinhado-centro borda-base espaco-vertical">

	  	<p>Só é possivel editar o tipo de Pokemon.</p>
  	</div>
<form name="formCadastro" id="formCadastro" class="form-horizontal" enctype="multipart/form-data" method="POST" action="{url}index.php/Cadastro/cadastrar">
  <label class="input-group">Tipo Atual:</label>

  <div class="input-group">

      <span class="input-group-addon"><i class="fa fa-user"></i></span>
      <input id="login" type="text" class="form-control" name="login" placeholder="--tipo atual--" required="">
  </div><br>
                            <div class="dropdown">
                              <label class="input-group">Alterar Tipo:</label>

                              <select data-toggle="dropdown" id="tipo" name=tipo class="btn btn-primary dropdown-toggle" required=""><span class="caret"></span>
                                    <ul class="dropdown-menu">
                                        <option value="" disabled selected hidden>Tipo</option>
                                        <option value="Verde">Verde</option>
                                        <option value="Laranja">Laranja</option>
                                        <option value="Vermelho">Vermelho</option>

                                    </ul>
                              </select>

                            </div>
                            <br>
                            <div class="form-group">
                                <!-- Button -->
                                <div class="col-sm-12 controls">

                                        <button type="submit" href="#" class="btn btn-success"><i class="fa fa-sign-in"></i> Editar</button>
                                        <a id="botao" class="btn btn-danger" href="http://localhost/pokemon/index.php/Home" >Cancelar</a></li></th><br />


                                </div>
                            </div>

                        </form>
</fieldset>
</form>
</div>
